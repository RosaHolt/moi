﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Label2_Load(object sender, EventArgs e)
        {

            Label2.Text = DateTime.Now.ToLongDateString();

        }



    }
}
      